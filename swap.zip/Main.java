/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner in = new Scanner(System.in);
	    System.out.println("enter the first number");
	    int n = in.nextInt();
	    System.out.println("enter the second number");
	    int m = in.nextInt();
	    System.out.println("before swapping"+"m is"+m+"n is "+n);
	    m= m^n;
	    n=m^n;
	    m=m^n;
	    System.out.println("after swapping m is"+m+"n is"+n);
	}
}
