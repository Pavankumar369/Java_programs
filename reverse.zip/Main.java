/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    int n,r=0;
	    Scanner in = new Scanner(System.in);
	    n= in.nextInt();
	    while(r!=0){
	        r=n%10;
	        System.out.println("r");
	        n=n/10;
	    }
	    
	    
	    
	}
}
