/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a[][] = {{1,0,0},{0,1,0},{0,0,1}};
	    boolean flag = true;
	    int rows = a.length;
	    int cols = a[0].length;
	    if(rows!=cols){
	        System.out.println("the matrix should be square matrix");
	    }
	    for(int i = 0;i<rows;i++){
	        for(int j = 0;j<cols;j++){
	            if(i ==j&&a[i][j] != 1 ){
	                flag = false;
	                break;
	            }
	            if(i!=j && a[i][j] != 0){
	                flag = false;
	                break;
	            }
	        }
	    }
		if(flag){
		    System.out.println("the matrix is identity matrix");
		    
		}
		else{
		    System.out.println("the matrix is not a identity matrix");
		    
		}
	}
}
