/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a[][] = {{1,2,3},{1,2,3},{1,2,3}};
	    int counteven=0,countodd=0;
	    int rows = a.length;
	    int col = a[0].length;
	    for(int i=0;i<rows;i++){
	        for(int j = 0;j<col;j++){
	            if(a[i][j] %2 ==0 ){
	                counteven++;
	            }
	            else{
	                countodd++;
	            }
	        }
	    }
		System.out.println("frequency of odd numbers is: "+counteven);
		System.out.println("frequency of odd numbers is: "+countodd);
	}
}
