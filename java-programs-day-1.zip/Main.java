/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    int i,n,count=0;
	    System.out.println("enter the number");
	    Scanner in = new Scanner(System.in);
	    n = in.nextInt();
	    for(i=1;i<=n;i++){
	        if(n%i==0){
	            count++;
	        }
	    }
	    if(count==2){
	        System.out.println("It is prime");
	    }
	    else{
	        System.out.println("it is not prime");
	    }
	}
}
