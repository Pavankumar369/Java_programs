public class Main
{
	public static void main(String[] args) {
	    int a[] = {1,2,3,4,5};
		System.out.println("elements at odd position are");
		for(int i=0;i<a.length;i = i+2){
		    System.out.print(a[i]+" ");
		}
	}
}
