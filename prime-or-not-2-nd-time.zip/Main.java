/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner in = new Scanner(System.in);
	    int n = in.nextInt();
	    int count = 0;
	    if(n>1){
	        for(int i =1;i<=n;i++){
	            if(n%i==0){
	                count++;
	            }
	        }
	        if(count==2){
	            System.out.println(" prime number");
	        }
	        else{
	            System.out.println("not a prime number");
	        }
	    }
	    else{
		System.out.println("not a prime number");
	        
	    }
	}
}
