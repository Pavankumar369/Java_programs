/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a[] = {10,20,20,30,30,40,50,50};
	    for(int i=0;i<a.length;i++){
	        for(int j = i+1;j<a.length;j++){
	            if(a[i] == a[j]){
	                a[i] =-1;
	            }
	        }
	    }
	    System.out.println(" the array without duplicates is");
	    for(int i=0;i<a.length;i++){
	        if(a[i]!=-1){
	        System.out.print(a[i]+" ");
	            
	        }
	        
	    }
	    
	}
	
}
