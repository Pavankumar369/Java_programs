/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    String str = "aaaabbbbcccc";
	    int len = str.length();
	    int n = 3;
	    int temp=0,chars;
	    chars = len/n;
	    String[] equalstring = new String[n];
	    if(len%n != 0){
	        System.out.println("string cannot be divided");
	        
	    }
	    else{
	        for(int i = 0;i<len;i = i+chars){
	            String part = str.substring(i,i+chars);
	            equalstring[temp] = part;
	            temp++;
	        }
	        
	        
	        
	    }
	    System.out.println(n+" string parts are");
	    for(int i = 0;i<n;i++){
	        System.out.println(equalstring[i]);
	    }
		//System.out.println("Hello World");
	}
}
