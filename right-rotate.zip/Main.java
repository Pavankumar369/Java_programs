/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a[] = {1,2,3,4,5};
	    int n=3;
	    
		System.out.println("the original array is");
		for(int i=0;i<a.length;i++){
		    System.out.println(a[i]);
		}
		//int j,last;
		//last = a[a.length-1];
		
		for( int i=0;i<n;i++){
		    int j,last;
		    last = a[a.length-1];
		    for(j=a.length-1;j>0;j--){
		        a[j] = a[j-1];
		    }
		    a[0] = last;
		}
		System.out.println();
		System.out.println(" array after right rotation ");
		for(int i=0;i<a.length;i++){
		    System.out.println(a[i]);
		}
	}
}
