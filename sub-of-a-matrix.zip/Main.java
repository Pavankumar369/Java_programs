/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a[][] = {{1,1,1},{1,1,1},{1,1,1}};
	    int b[][] = {{1,1,1},{1,1,1},{1,1,1}};
	    int rows = a.length;
	    int columns = a[0].length;
	    int c[][] = new int[rows][columns];
	    for(int i = 0;i<rows;i++){
	        for(int j = 0;j<columns;j++){
	            c[i][j] = a[i][j]-b[i][j];
	            
	        }
	    }
	    for(int i=0;i<rows;i++){
	        for(int j=0;j<columns;j++){
	            System.out.print(c[i][j]+" ");
	        }
	        System.out.println();
	    }
		//System.out.println();
	}
}
