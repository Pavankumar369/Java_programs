/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a[][] = {{1,2,3},{1,2,3},{1,2,3}};
	    int r = a.length;
	    int c = a[0].length;
	    int rowsum;
	    int colsum;
	    for(int i=0;i<r;i++){
	        rowsum = 0;
	        for(int j= 0;j<c;j++){
	            rowsum = rowsum+a[i][j];
	        }
	        System.out.println("sum of "+(i+1)+" row elements is "+rowsum);
	    }
	    for(int i=0;i<r;i++){
	        colsum = 0;
	        for(int j= 0;j<c;j++){
	            
	            colsum = colsum+a[j][i];
	        }
	        System.out.println("sum of"+(i+1)+" column elements is "+colsum);
	    }
	    //System.out.println("sum of row elements is "+rowsum);
		//System.out.println("sum of column elements is "+colsum);
	}
}
