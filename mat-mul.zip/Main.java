/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a[][] = {{1,1},{1,1}};
	    int b[][] = {{1,1},{1,1}};
	    int c[][] = new int[2][2];
		System.out.println("multiplication of matrix is:");
		for(int i=0;i<2;i++){
		    for(int j=0;j<2;j++){
		        c[i][j] = 0;
		        for(int k=0;k<2;k++){
		            c[i][j] = c[i][j]+a[i][k]*b[k][j];
		        }
		    }
		}
		for(int i=0;i<2;i++){
		    for(int j=0;j<2;j++){
		        System.out.print(c[i][j]+" ");
		    }
		    System.out.println();
		}
	}
}
