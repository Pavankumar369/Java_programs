/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("enter the number");
		int n,rev=0,org;
		Scanner in = new Scanner(System.in);
		n = in.nextInt();
		org=n;
		while(n!=0){
		    rev = rev*10+num%10;
		    n= n/10;
		}
		if(rev=org){
		    System.out.println("Palindrome");
		}
		else{
		    System.out.println("not palindrome");
		}
		
		
	}
}
