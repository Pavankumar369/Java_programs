/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
	    char ch1 ='a';
	    char ch2 ='b';
	    int ascii1 = ch1;
	    int ascii2 = ch2;
	    
		System.out.println(ascii1+" "+ascii2);
	}
}
