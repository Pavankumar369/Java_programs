/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a[] = {11,22,36,44,59};
		System.out.println("odd elements");
		for(int i=0;i<a.length;i++){
		    if(a[i]%2!=0){
		        System.out.print(a[i]+" ");
		    }
		}
		System.out.println("\n"+"even elements ");
		for(int i=0;i<a.length;i++){
		    if(a[i]%2==0){
		        System.out.print(a[i]+" ");
		    }
		}
	}
}
