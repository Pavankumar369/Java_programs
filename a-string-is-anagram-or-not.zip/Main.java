/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Arrays;
public class Main
{
	public static void main(String[] args) {
	    String str1 = "grab";
	    String str2 = "prag";
	    str1 = str1.toLowerCase();
	    str2 = str2.toLowerCase();
	    if(str1.length() != str2.length()){
	        System.out.println("it is not an anagram");
	    }
	    else{
	        char[] st1 = str1.toCharArray();
	        char[] st2 = str2.toCharArray();
	        Arrays.sort(st1);
	        Arrays.sort(st2);
	        if(Arrays.equals(st1,st2)== true){
	            System.out.println("it is an anagram");
	            
	        }
	        else
	        System.out.println("it is not an anagram");
	        
	    }
		//System.out.println(string1);
	}
}
