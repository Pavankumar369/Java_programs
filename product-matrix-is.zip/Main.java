/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a[][] = {{1,2,3},{1,2,3},{1,2,3}};
	    int b[][] = {{1,2,3},{1,2,3},{1,2,3}};
	   // int c[][] = new int[][];
	    int r1,r2,c1,c2;
	    r1 = a.length;
	    c1 = a[0].length;
	    r2 = b.length;
	    c2 = b[0].length;
	    int c[][] = new int[r1][c2];
	    if(c1!=r2){
	        System.out.println("matrix multiplication is not possible");
	    }
	    for(int i=0;i<r1;i++){
	        for(int j=0;j<c2;j++){
	            c[i][j] = 0;
	            for(int k=0;k<r2;k++){
	                c[i][j] = c[i][j]+a[i][k]*b[k][j];
	            }
	        }
	    }
	    System.out.println("product matrix is ");
	    for(int i =0;i<r1;i++){
	        for(int j = 0;j<c2;j++){
	            System.out.print(c[i][j]+" ");
	        }
	        System.out.println();
	    }
		
	}
}
