/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
	    int r1,c1,r2,c2,i,j;
	    int m1[][] = {{1,1},{1,1}};
	    int m2[][] = {{1,1},{1,1}};
	    boolean flag = true;
	    Scanner in = new Scanner(System.in);
	    System.out.println("enter r1 of m1");
	    r1 = in.nextInt();
		System.out.println("enter c1 of m1");
		c1 = in.nextInt();
		System.out.println("enter r2 of m2");
		r2 = in.nextInt();
		System.out.println("enter c2 of m2");
		c2 = in.nextInt();
		if(r1!=r2 || c1!=c2){
		    System.out.println("they are not equal");
		    
		}
		else{
		    System.out.println("enter the elements of m1");
		     for(i=0;i<r1;i++){
		        for(j=0;j<c1;j++){
		            System.out.print(m1[i][j]+" ");
		        }
		        System.out.println();
		        
		    }
		    System.out.println("enter the elements of m2");
		    for(i=0;i<r2;i++){
		        for(j=0;j<c2;j++){
		            System.out.print(m2[i][j]+" ");
		        }
		        System.out.println();
		        
		    }
		    for(i=0;i<r1;i++){
		        for(j=0;j<c1;j++){
		            if(m1[i][j] != m2[i][j]){
		                
		                flag = false;
		                break;
		            }
		            
		        }
		        
		    }
		    if(flag){
		    System.out.println("both are equal");}
		    else{
		    System.out.println("both are not equal");}
	    }
	}
}
