/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) 
	{
		int arr[] = {1,2,3,4,5,6};
		for (int i=0;i<arr.length;i++){
		    System.out.print(arr[i]+" ");
		}
		System.out.println("enter the no of shift:");
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		//System.out.println("enter the no of shift")
		for(int i=0;i<n;i++){
		    int first = arr[0];
		    for(int j=0;j<arr.length-1;j++){
		        arr[j] = arr[j+1];
		        
		    }
		        arr[arr.length-1] = first;
		    
		}
		System.out.println("the new array is ");
		for(int i=0;i<arr.length;i++){
		    System.out.print(arr[i]+" ");
		}
	}
}
