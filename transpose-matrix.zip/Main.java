public class Main{
    public static void main(String [] args){
        int a[][] = {{1,2,3},{1,2,3},{1,2,3}};
        int t[][] = new int[3][3];
        for(int i = 0;i<3;i++){
            for(int j = 0;j<3;j++){
                t[i][j] = a[j][i];
            }
        }
        System.out.println("original matrix");
        for(int i = 0;i<3;i++){
            for(int j = 0;j<3;j++){
                System.out.print(a[i][j]+" ");
            }
            System.out.println();
            
        }
        System.out.println("transpose matrix");
        for(int i = 0;i<3;i++){
            for(int j = 0;j<3;j++){
                System.out.print(t[i][j]+" ");
            }
            System.out.println();
        }
        
    }
}
