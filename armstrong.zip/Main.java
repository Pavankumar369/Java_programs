
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int r,sum = 0;
		int org;
		org= n;
		while(n>0){
		    r = n%10;
		    n = n/10;
		    sum = sum+r*r*r;}
	
	if(sum==org){
	    System.out.println("armstrong");
	    	}
	else{
	    System.out.println("not armstrong");
	}}}
