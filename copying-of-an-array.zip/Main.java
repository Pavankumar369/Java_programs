/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("enter the first array elements");
		int a[] = new int[5];
		int b[] = new int[5];
	    Scanner in = new Scanner(System.in);
	    for(int i = 0;i<5;i++){
	        a[i] = in.nextInt();
	    }
	
	    
	    for(int i = 0;i<5;i++){
	        System.out.print(a[i]+" ");
	    }
	    System.out.print("/nthe copied array elements are");
	    for(int i =0;i<5;i++){
	        b[i] = a[i];
	        System.out.print(b[i]+" ");
	    }
	}
	
}
