public class Main
{
	
	public static int getLargest(int a[],int total){
	    int temp=0;
	    for(int i=0;i<total;i++){
	        for(int j =i+1;j<total;j++){
	            if(a[i] > a[j]){
	                temp = a[i];
	                a[i] = a[j];
	                a[j] = temp;
	            }
	        }
	    }
	    return a[total-2];
	}
	public static void main(String[] args) {
	    int a[] = {24,23,25,4,4};
	    int b[] = {44,66,99,77,33,22,55};
		System.out.println(" the second largest number is "+getLargest(a,5));
		System.out.println(" the second largest number is "+getLargest(b,7));
	}
}


