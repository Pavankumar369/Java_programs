public class Main
{
	public static void main(String[] args)
	{
	    int a[] = {5,2,6,4,3};
	    int temp =0;
	    for(int i=0;i<a.length;i++)
	    {
	        System.out.print(a[i] +" ");
	    }
	    for(int i=0;i<a.length;i++)
	    {
	        for(int j=i+1;j<a.length;j++)
	        {
	            if(a[i] < a[j])
	            {
	                temp = a[i];
	                a[i] = a[j];
	                a[j] = temp;
	                
	            }
	        }
	    }
	    System.out.println();
	     
	    System.out.println("elements in desending order");
	    for(int i = 0;i< a.length;i++)
	    {
	            System.out.println(a[i]+" ");
	    }
    }
}
