/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a[][] = {{4,0,0},{0,5,0},{0,0,6}};
	    int rows,cols,count = 0,size;
	    rows = a.length;
	    cols = a[0].length;
	    size = rows*cols;
	    for(int i = 0;i<rows;i++){
	        for(int j = 0;j<cols;j++){
	            if(a[i][j] ==0){
	                count++;
	            }
	        }
	    }
	    if(count>(size/2)){
	        System.out.println("it is sparse matrix");
	        
	    }
	    else{
	        System.out.println("it is not a sparse matrix");
	        
	    }
		//System.out.println("Hello World");
	}
}
