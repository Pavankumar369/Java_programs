/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a[] = {26,37,53,33,42};
	    int max =a[0];
	    for(i=0;i<a.length;i++){
	        if(a[i] > max){
	            max = a[i];
	        }
	    }
		System.out.println(max);
	}
}
