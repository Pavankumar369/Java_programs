public class Main{
    public static void main(String []args){
        int m1[][] = {{1,1,1},{1,1,1},{1,1,1}};
        int m2[][] = {{1,1,1},{1,1,1},{1,1,1}};
        int sum[][] = new int[3][3];
        int i,j;
        System.out.println("enter the first matrix");
        for(i=0;i<3;i++){
            for(j=0;j<3;j++){
                System.out.print(m1[i][j]+" ");
                
            }
            System.out.println();
            
        }
        System.out.println("enter the second matrix");
        for(i=0;i<3;i++){
            for(j=0;j<3;j++){
                System.out.print(m2[i][j]+" ");
                
            }
            System.out.println();
            
        }
        System.out.println("sum the both matrix");
        for(i=0;i<3;i++){
            for(j=0;j<3;j++){
                sum[i][j] = m1[i][j]+m2[i][j];
                
            }
            //System.out.println();
            
        }
        //System.out.println("sum the both matrix");
        for(i=0;i<3;i++){
            for(j=0;j<3;j++){
                System.out.print(sum[i][j]+" ");
                
            }
            System.out.println();
            
        }
        
        
        
    }
}
	            
	        
