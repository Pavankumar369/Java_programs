import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("enter the number");
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int sum=0;
		for(i=1;i<=n;i++){
		    sum = sum+i;
		}
		//sum= ((n)*(n+1))/2;
		System.out.println("sum is "+sum);
		
	}
}