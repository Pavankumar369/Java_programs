public class Main
{
	public static void main(String[] args) {
	    int a[] = {26,37,53,33,42};
	    int sum =0;
	    for(int i = 0;i<a.length;i++){
	        sum = sum+a[i];
	    }
	    
		System.out.println(sum);
	}
}